"""Bounded, server-authenticated public raid reads; no AI or general URL fetch."""
from datetime import datetime,timezone
from time import monotonic

from server.app.chickenbro.wcl_source import _graphql
from .battle_analysis import analyze_battle, select_windows

CONTEXT_QUERY='''query QqBattleContext($code:String!){reportData{report(code:$code){
 code visibility title fights{id name encounterID difficulty kill startTime endTime
 friendlyPlayers inProgress keystoneLevel}
 masterData{actors{id name type subType petOwner} abilities{gameID name}}}}}'''
TABLES_QUERY='''query QqBattleTables($code:String!,$ids:[Int]){reportData{report(code:$code){
 playerDetails(fightIDs:$ids,includeCombatantInfo:false)
 damage:table(fightIDs:$ids,dataType:DamageDone)
 healing:table(fightIDs:$ids,dataType:Healing)}}}'''
EVENTS_QUERY='''query QqBattleEvents($code:String!,$ids:[Int],$type:EventDataType,
 $start:Float,$end:Float,$limit:Int){reportData{report(code:$code){
 events(fightIDs:$ids,dataType:$type,startTime:$start,endTime:$end,limit:$limit){data nextPageTimestamp}}}}'''


def number(value):
    from math import isfinite
    return type(value) in (int,float) and isfinite(value)


def read_events(fetch,variables,*,max_pages=4):
    start,end=variables['start'],variables['end'];cursor=start;rows=[];complete=False;pages=0;semantic_complete=True
    for _ in range(max_pages):
        try:page=fetch({**variables,'start':cursor,'limit':1000})
        except Exception:break
        pages+=1
        if not isinstance(page,dict) or not isinstance(page.get('data'),list) or 'nextPageTimestamp' not in page:break
        next_cursor=page['nextPageTimestamp']
        if next_cursor is not None and (not number(next_cursor) or not cursor<next_cursor<=end):break
        boundary=next_cursor if next_cursor is not None else end
        events=page['data']
        if len(events)>1000 or any(not isinstance(e,dict) or not number(e.get('timestamp')) for e in events):break
        # A continuation boundary belongs only to the following page. Identical
        # events inside one page remain distinct legitimate log events.
        for event in events:
            if not cursor<=event['timestamp']<boundary:continue
            semantic=True
            if variables.get('type') in ('Deaths','DamageTaken'):
                expected='death' if variables['type']=='Deaths' else 'damage'
                semantic=(event.get('type')==expected and type(event.get('targetID')) is int)
                if variables['type']=='DamageTaken':semantic=semantic and number(event.get('amount')) and event['amount']>=0
                if 'fight' in event:semantic=semantic and event['fight'] in variables.get('ids',[])
            if semantic:rows.append(event)
            else:semantic_complete=False
        cursor=boundary
        if next_cursor is None:complete=semantic_complete;break
    return {'events':rows,'complete':complete,'pages':pages,'startTime':start,'endTime':end,
            'observedThrough':cursor,'dataType':variables.get('type')}


class BattleSource:
    def __init__(self,*,graphql=None,clock=monotonic):
        self.graphql=graphql or _graphql;self.clock=clock

    def query(self,request,*,context=None):
        if not request.url:
            if isinstance(context,dict) and context.get('schema')=='qq-battle-v1' and context.get('status')=='ready':
                return context
            return {'status':'missing_context'}
        deadline=self.clock()+100;calls=0
        def read(query,variables):
            nonlocal calls
            remaining=deadline-self.clock()
            if calls>=18 or remaining<=0:raise TimeoutError()
            calls+=1
            data=self.graphql(query,variables,timeout_seconds=min(15,remaining))
            if data.get('_fieldErrors'):raise ValueError('partial GraphQL fields')
            result=(data.get('reportData') or {}).get('report')
            if not isinstance(result,dict):raise ValueError('missing report')
            return result
        code=request.url.rsplit('/',1)[-1]
        try:
            raw=read(CONTEXT_QUERY,{'code':code})
            if raw.get('code')!=code or raw.get('visibility')!='public':
                return {'status':'blocked','message':'只支持可公开读取的 WCL 报告。'}
            fights=[f for f in raw.get('fights',[]) if isinstance(f,dict) and
                    type(f.get('id')) is int and type(f.get('encounterID')) is int and f['encounterID']>0 and
                    f.get('difficulty') in (1,3,4,5) and not f.get('keystoneLevel') and
                    type(f.get('kill')) is bool and f.get('inProgress') is False and
                    number(f.get('startTime')) and number(f.get('endTime')) and 0<=f['startTime']<f['endTime']]
            if request.fight_id is None:
                if not fights:return {'status':'blocked','message':'该报告没有可分析的已结束团本首领战斗。'}
                return {'status':'selection','sourceUrl':request.url,'fights':sorted(fights,key=lambda f:f['startTime'],reverse=True)[:5]}
            fight=next((f for f in fights if f['id']==request.fight_id),None)
            if fight is None:return {'status':'blocked','message':'该场次不存在、仍在进行，或不属于已结束的团本首领战斗。'}
            variables={'code':code,'ids':[fight['id']],'start':fight['startTime'],'end':fight['endTime']}
            tables={}
            try:tables=read(TABLES_QUERY,{'code':code,'ids':[fight['id']]})
            except Exception:pass
            def fetch(v):return read(EVENTS_QUERY,v).get('events')
            deaths=read_events(fetch,{**variables,'type':'Deaths'},max_pages=3)
            windows=[]
            for start,end in select_windows(fight,deaths['events']):
                page=read_events(fetch,{**variables,'type':'DamageTaken','start':start,'end':end},max_pages=4)
                windows.append(page)
            packet=analyze_battle(code,request.url,fight,raw.get('masterData') or {},tables,deaths,windows)
            if not (packet['good'] or packet['deaths'] or packet['damageWindows'] or
                    (packet['coverage']['actors'] and packet['coverage']['deaths'])):
                return {'status':'unavailable'}
            packet.update(readAt=datetime.now(timezone.utc).isoformat(),sourceCalls=calls)
            return packet
        except Exception:
            return {'status':'unavailable'}
