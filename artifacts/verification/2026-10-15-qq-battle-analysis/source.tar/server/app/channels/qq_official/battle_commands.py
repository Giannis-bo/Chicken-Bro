"""Fixed battle commands and paragraph-budgeted single-message presentation."""
from dataclasses import dataclass
import re
import shlex
from urllib.parse import parse_qsl, urlsplit

from server.app.chickenbro.wcl_source import normalize_wcl_report_url
from server.app.simulation.sources import parse_character_source_url

BATTLE_COMMANDS = {'/战斗分析':'battle_summary', '/战斗详情-大腿':'battle_good',
                   '/战斗详情-毒瘤':'battle_review'}
BATTLE_HELP = ('/战斗分析 WCL报告链接 [场次=5]\n'
               '/战斗详情-大腿：本人的上次战斗，最多3名贡献角色\n'
               '/战斗详情-毒瘤：本人的上次战斗，最多3名承伤／减员复盘角色\n'
               '两个详情命令也可填写 WCL报告链接 [场次=5]。')
MESSAGE_LIMIT = 1200


@dataclass(frozen=True)
class BattleRequest:
    kind: str
    url: str = ''
    fight_id: int | None = None


def parse_battle(text):
    from .query_commands import QueryInputError
    if not isinstance(text,str) or len(text)>1024:
        raise QueryInputError('战斗指令请控制在1024字符内。')
    try: parts=shlex.split(text)
    except ValueError: raise QueryInputError('指令引号未闭合。') from None
    if not parts or parts[0] not in BATTLE_COMMANDS:
        raise QueryInputError(BATTLE_HELP)
    kind=BATTLE_COMMANDS[parts[0]]
    if len(parts)==1 and kind!='battle_summary':return BattleRequest(kind)
    if not 2<=len(parts)<=3:raise QueryInputError(BATTLE_HELP)
    try:
        raw=urlsplit(parts[1])
        keys=[k for k,v in parse_qsl(raw.query,keep_blank_values=True)+parse_qsl(raw.fragment,keep_blank_values=True)]
        if len(keys)!=len(set(keys)):raise ValueError()
        parsed=parse_character_source_url(normalize_wcl_report_url(parts[1]))
        if not parsed.report_code or not re.fullmatch(r'[A-Za-z0-9]{16}',parsed.report_code):raise ValueError()
        fight=parsed.fight_id
        if len(parts)==3:
            if not re.fullmatch(r'场次=[1-9][0-9]{0,5}',parts[2]):raise ValueError()
            fight=int(parts[2].split('=')[1])
        return BattleRequest(kind,'https://www.warcraftlogs.com/reports/'+parsed.report_code,fight)
    except (ValueError,TypeError,AttributeError):
        raise QueryInputError('请填写有效的 WCL 报告链接，可补充 场次=5；场次须为正整数且不能重复。') from None


def clock_text(seconds):
    value=max(0,int(seconds))
    return f'{value//60:02d}:{value%60:02d}'


def amount_text(value):
    return f'{value/10000:.1f}万' if value>=10000 else str(round(value))


def format_battle(packet,kind='battle_summary'):
    from .query_commands import markdown_text as md
    from .query_labels import label
    status=packet.get('status')
    if status=='missing_context':return '请先发送 /战斗分析 WCL报告链接，选择一场战斗后再查看详情。'
    if status=='unavailable':return 'WCL 日志读取失败或超时，请稍后重试。'
    if status=='blocked':return packet.get('message','当前报告或场次不可分析。')[:MESSAGE_LIMIT]
    if status=='selection':
        header='# 请选择战斗场次'
        blocks=[f'**第{f["id"]}场 · {md(label(f["name"]),45)}**｜'+('已击杀' if f['kill'] else '灭团')+
                '｜'+clock_text((f['endTime']-f['startTime'])/1000) for f in packet['fights'][:5]]
        footer='发送：/战斗分析 '+packet['sourceUrl']+' 场次=编号\n展示最近最多5场；可填写日志中的实际场次编号。'
    else:
        fight=packet['fight'];url=packet['sourceUrl']+'?fight='+str(packet['fightId'])
        titles={'battle_summary':'战斗分析','battle_good':'战斗详情·大腿','battle_review':'战斗详情·毒瘤'}
        header='# '+md(label(fight['name']),45)+' · '+titles[kind]+'\n**'+packet['difficulty']+'｜'+('已击杀' if fight['kill'] else '灭团')+'｜'+clock_text(packet['duration'])+'｜'+str(packet['playerCount'])+'人**'
        if kind=='battle_summary':
            blocks=list(packet.get('highlights',[]))[:3]
        elif kind=='battle_good':
            blocks=[]
            for i,row in enumerate(packet.get('good',[])[:3],1):
                metric='记录伤害' if row['metric']=='damage' else '有效治疗'
                blocks.append(f'**{i}. {md(row["name"],35)}｜{row["roleLabel"]}贡献**\n'+
                    f'{metric}{amount_text(row["amount"])}，占同职责已核验总量{row["share"]:.1f}%；同职责第{row["rank"]}/{row["roleCount"]}。\n'+
                    f'[整场{metric}记录]({url}&source={row["actorId"]})')
            if not blocks:blocks=['暂无足够完整的职责贡献证据。']
        else:
            blocks=[]
            for i,row in enumerate(packet.get('review',[])[:3],1):
                death=row['death'];hits=row.get('hits',[])
                detail='；'.join(clock_text(h['time'])+' '+md(h['ability'],30)+' '+amount_text(h['amount']) for h in hits[-3:])
                blocks.append(f'**{i}. {md(row["name"],35)}｜减员复盘**\n'+
                    f'{clock_text(death["time"])}死亡，本场已记录死亡{row["deathCount"]}次。\n'+
                    ('死亡前5秒已读取伤害：'+detail+'。\n' if hits else '')+
                    f'[查看本场日志]({url})')
            if not blocks:blocks=['暂无可展开的死亡前承伤证据。']
            blocks.append('选人依据：已读取的死亡前承伤与减员事件，按首次死亡时间排序。')
        gaps=packet.get('gaps',[])
        if gaps:blocks.append('读取范围未完整：'+'；'.join(gaps[:3])+'。')
        footer=f'[WCL原始日志]({url}) · 第{packet["fightId"]}场'
        if kind=='battle_summary':footer+='\n详情：/战斗详情-大腿 · /战斗详情-毒瘤'
    # Reserve footer and only include whole evidence-bearing paragraphs.
    output=header
    for block in blocks:
        if len(output)+len(block)+len(footer)+4<=MESSAGE_LIMIT:output+='\n\n'+block
    return output+'\n\n'+footer
